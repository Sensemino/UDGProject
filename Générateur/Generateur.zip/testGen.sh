generer Exemples/desAges.xml  ; grep Nbligne Exemples/desAges.xml ; nbl Sorties/ghAGES.csv 
