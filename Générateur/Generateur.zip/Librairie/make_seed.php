<?php
function make_seed($var){//fabrique une seed
  return rand(2,100)*$var;
}
?>
