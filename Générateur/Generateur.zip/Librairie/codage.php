<?php

// retourne un tableau en faisant le lien avec la colonne précédente
// qui est num�rique : exemple de formule de codage : 1;homme;2;femme

function codage($leCodage, $donnees, $nbligne,$nom,$PremierPassage ) {
#echo  " input pour passage $PremierPassage " ;
#print_r($donnees) ;
    $decale = 0 ;
    if ($PremierPassage==0) { $decale = 1 ; } ;
    $donnees[0+$decale] = $nom ; # car en 0 c'est d�j� [reference]

    $tab_Formule = explode(";", $leCodage) ;

    for ($i = 1 + $decale ; $i <= $nbligne + $decale ; $i++) { # on commence � 2 car en 1 c'est le nom de la colonne
        for ($j = 0; $j < count($tab_Formule); $j = $j + 2) {
            if ($donnees[$i] == $tab_Formule[$j]) {
                $donnees[$i] = $tab_Formule[$j + 1];
            } # fin si
        } # fin pour
    } # fin pour
#echo  " output " ;
#print_r($donnees) ;

    return $donnees;

} # fin fonction codage
?>
