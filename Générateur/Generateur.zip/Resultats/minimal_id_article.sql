# generated via Exemples/minimal.xml;

DROP TABLE IF EXISTS minimal_id_article;

CREATE TABLE minimal_id_article (
    id VARCHAR(255)  ,
    article VARCHAR(255)   ,
    PRIMARY KEY (`id`)
) ; 

INSERT INTO minimal_id_article (id,article) VALUES (1,'GBU-22') ;
INSERT INTO minimal_id_article (id,article) VALUES (2,'WNP-91') ;
INSERT INTO minimal_id_article (id,article) VALUES (3,'YTu-11') ;
INSERT INTO minimal_id_article (id,article) VALUES (4,'JUO-87') ;
INSERT INTO minimal_id_article (id,article) VALUES (5,'ZKR-66') ;
INSERT INTO minimal_id_article (id,article) VALUES (6,'GDx-46') ;
INSERT INTO minimal_id_article (id,article) VALUES (7,'XYs-61') ;
INSERT INTO minimal_id_article (id,article) VALUES (8,'WHd-22') ;
INSERT INTO minimal_id_article (id,article) VALUES (9,'CEh-76') ;
INSERT INTO minimal_id_article (id,article) VALUES (10,'NUN-45') ;
INSERT INTO minimal_id_article (id,article) VALUES (11,'ERa-40') ;
INSERT INTO minimal_id_article (id,article) VALUES (12,'UQD-49') ;
INSERT INTO minimal_id_article (id,article) VALUES (13,'NZB-74') ;
INSERT INTO minimal_id_article (id,article) VALUES (14,'AHF-16') ;
