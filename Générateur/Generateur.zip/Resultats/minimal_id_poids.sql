# generated via Exemples/minimal.xml;

DROP TABLE IF EXISTS minimal_id_poids;

CREATE TABLE minimal_id_poids (
    id VARCHAR(255)  ,
    poids VARCHAR(255)   ,
    PRIMARY KEY (`id`)
) ; 

INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0001',62) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0002',174) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0003',232) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0004',93) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0005',225) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0006',210) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0007',52) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0008',NULL) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0009',136) ;
INSERT INTO minimal_id_poids (id,poids) VALUES ('MAT0010',201) ;
