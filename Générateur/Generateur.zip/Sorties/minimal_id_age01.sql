# generated via Exemples/minimal.xml;

DROP TABLE IF EXISTS minimal_id_age01;

CREATE TABLE minimal_id_age01 (
    id VARCHAR(255)  ,
    age VARCHAR(255)   ,
    PRIMARY KEY (`id`)
) ; 

INSERT INTO minimal_id_age01 (id,age) VALUES (1,83) ;
