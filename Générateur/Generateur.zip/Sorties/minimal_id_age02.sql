# generated via Exemples/minimal.xml;

DROP TABLE IF EXISTS minimal_id_age02;

CREATE TABLE minimal_id_age02 (
    id VARCHAR(255)  ,
    age VARCHAR(255)   ,
    PRIMARY KEY (`id`)
) ; 

INSERT INTO minimal_id_age02 (id,age) VALUES (1,83) ;
INSERT INTO minimal_id_age02 (id,age) VALUES (2,90) ;
INSERT INTO minimal_id_age02 (id,age) VALUES (3,3) ;
INSERT INTO minimal_id_age02 (id,age) VALUES (4,11) ;
INSERT INTO minimal_id_age02 (id,age) VALUES (5,81) ;
INSERT INTO minimal_id_age02 (id,age) VALUES (6,43) ;
